<?php

namespace InfluxDB2;

class WriteType
{
    const SYNCHRONOUS = 1;
    const BATCHING = 2;
}
