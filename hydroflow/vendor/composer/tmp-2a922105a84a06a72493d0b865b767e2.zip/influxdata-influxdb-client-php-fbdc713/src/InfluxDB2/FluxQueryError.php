<?php

namespace InfluxDB2;

use RuntimeException;

class FluxQueryError extends RuntimeException
{
}
